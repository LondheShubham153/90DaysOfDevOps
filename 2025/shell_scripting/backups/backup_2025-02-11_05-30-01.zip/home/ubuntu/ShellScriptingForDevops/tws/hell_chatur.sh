#!/bin/bash

echo "Sabhaki Namaskaram Aaj Andharam "

echo "Rancho : Ratta MAREGA"


echo "Virus: bAYATAKI PORA GADIDHA"

echo " Virus: nuvvu antha thopu ayithe oka folder create chey ra puka "

echo "pani: algt bhai"

mkdir -p Chusko

if [[ -d Chusko ]];
then
	echo " You are great"
fi

